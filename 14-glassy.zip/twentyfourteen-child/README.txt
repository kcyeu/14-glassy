14-Glassy
==========

14-Glassy is derived from the WordPress 2014 official theme, fine-tuned for mobile devices to improve readability. Support native color scheme and Fourteen Colors Plugin. See [website] (http://mikuru.tw/ "kmd's  Weblog") for demo.

License
--------
The images in the screenshot are adopted from http://skitterphoto.com/ and licensed under CC0.
